import React from 'react'

const AsidePage = () => {
  return <div className="w-2/4">AsidePage</div>;
}

export default AsidePage