import TwitterPage from "./views/TwitterPage";

const App = () => {
  return (
    <div className="min-h-screen">
      <TwitterPage />
    </div>
  )
}

export default App
